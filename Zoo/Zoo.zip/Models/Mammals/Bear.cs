﻿namespace Zoo
{
    class Bear : Mammal
    {
        public Bear(string name) : base(name)
        {
        }
    }
}
