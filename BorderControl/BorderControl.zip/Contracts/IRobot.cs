﻿
namespace BorderControl
{
    public interface IRobot
    {
        public string Model { get; }
    }
}
