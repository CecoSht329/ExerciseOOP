﻿
namespace BorderControl
{
    public interface IBuyer
    {
        public int Food { get; }

        public int BuyFood();
    }
}
