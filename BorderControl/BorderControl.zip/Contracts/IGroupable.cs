﻿
namespace BorderControl.Contracts
{
    public interface IGroupable
    {
        public string Group { get; }
    }
}
