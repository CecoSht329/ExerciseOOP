﻿
namespace BorderControl
{
    public interface INameable
    {
        public string Name { get; }
    }
}
