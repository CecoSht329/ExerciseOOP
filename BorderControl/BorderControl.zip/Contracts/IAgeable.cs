﻿
namespace BorderControl
{
    public interface IAgeable
    {
        public string Age { get; }
    }
}
