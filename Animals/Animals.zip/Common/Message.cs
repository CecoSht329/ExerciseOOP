﻿namespace Animals.Common
{
    public class Message
    {
        internal const string ArgumentExceptionMessage = "Invalid input!";
    }
}
