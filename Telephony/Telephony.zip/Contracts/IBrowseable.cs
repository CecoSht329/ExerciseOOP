﻿namespace Telephony
{
    public interface IBrowseable
    {
        public void Browse(string site);
    }
}
