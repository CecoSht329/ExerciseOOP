﻿
namespace MilitaryElite
{
    public static class MissionState
    {
        public const string Finished = "finished";
        public const string InProgress = "inProgress";
    }
}
