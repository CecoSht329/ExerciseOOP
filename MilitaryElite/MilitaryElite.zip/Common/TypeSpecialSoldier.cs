﻿
namespace MilitaryElite
{
    public static class TypeSpecialSoldier
    {
        public const string Marines = "Marines";
        public const string Airforces = "Airforces";
    }
}
