﻿
namespace MilitaryElite
{
    public interface ISoldier
    {
        //•	Soldier - general class for Soldiers, holding id, first name and last name.
        public string Id { get; }
        public string FirstName { get; }
        public string LastName { get; }
    }
}
