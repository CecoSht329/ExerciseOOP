﻿
namespace MilitaryElite
{
    public interface IPrivate
    {
        public double Salary { get; }
    }
}
