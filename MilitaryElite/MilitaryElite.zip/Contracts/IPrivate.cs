﻿
namespace MilitaryElite
{
    public interface IPrivate
    {
        //lowest base Soldier type, holding the salary(decimal). 
        public decimal Salary { get; }
    }
}
