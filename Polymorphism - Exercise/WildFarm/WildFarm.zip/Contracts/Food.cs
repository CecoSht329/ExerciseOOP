﻿
namespace WildFarm
{
    public abstract class Food
    {
        public abstract int Quantity { get; protected set; }

    }
}
