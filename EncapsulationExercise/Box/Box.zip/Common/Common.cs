﻿namespace Box.Common
{
    public class Common
    {
        public const string InvalidSizeMessage= "{0} cannot be zero or negative.";
    }
}
